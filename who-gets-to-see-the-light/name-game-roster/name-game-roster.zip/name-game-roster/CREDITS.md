# Where these portraits came from

Fifteen public-domain portraits, for demonstrating Name Game without using a single
student's photograph. Each one was checked against Wikimedia Commons licence metadata
and kept only if it came back public domain; Srinivasa Ramanujan was dropped because
his lead portrait is CC BY 4.0. All were re-encoded to plain RGB baseline JPEG, max
800px, so the app has nothing unusual to open.

Filenames are `First_Last_Demo_Portraits.jpg` — Name Game reads the name from the
filename, and the class filter reads `Demo Portraits`.

| Name | Licence | Source |
|---|---|---|
| W. E. B. Du Bois | Public domain | https://commons.wikimedia.org/wiki/File:W.E.B._Du_Bois_by_James_E._Purdy,_1907_(3x4).jpg |
| Rachel Carson | Public domain | https://commons.wikimedia.org/wiki/File:Rachel-Carson.jpg |
| George Washington Carver | Public domain | https://commons.wikimedia.org/wiki/File:George_Washington_Carver_c1910_-_Restoration.jpg |
| Marie Curie | Public domain | https://commons.wikimedia.org/wiki/File:Marie_Curie_c._1920s.jpg |
| Emily Dickinson | Public domain | https://commons.wikimedia.org/wiki/File:Black-white_photograph_of_Emily_Dickinson2.png |
| Frederick Douglass | Public domain | https://commons.wikimedia.org/wiki/File:Frederick_Douglass_(circa_1879)_(cropped).jpg |
| Katherine Johnson | Public domain | https://commons.wikimedia.org/wiki/File:Katherine_Johnson_1983.jpg |
| Ada Lovelace | Public domain | https://commons.wikimedia.org/wiki/File:Ada_Lovelace_daguerreotype_by_Antoine_Claudet_1843_-_cropped.png |
| Maria Mitchell | No restrictions | https://commons.wikimedia.org/wiki/File:Maria_Mitchell_portrait.jpg |
| Emmy Noether | Public domain | https://commons.wikimedia.org/wiki/File:Emmy_Noether_(3x4_cropped).jpg |
| Sojourner Truth | Public domain | https://commons.wikimedia.org/wiki/File:Sojourner_Truth,_1870_(cropped,_restored).jpg |
| Harriet Tubman | Public domain | https://commons.wikimedia.org/wiki/File:Carte-de-visite_portrait_of_Harriet_Tubman_(cropped).jpg |
| Mark Twain | Public domain | https://commons.wikimedia.org/wiki/File:Mark_Twain_by_AF_Bradley_(cropped_2).jpg |
| Booker T. Washington | Public domain | https://commons.wikimedia.org/wiki/File:Booker_T_Washington_retouched_flattened-crop.jpg |
| Phillis Wheatley | Public domain | https://commons.wikimedia.org/wiki/File:Phillis_Wheatley_frontispiece.jpg |

Assembled 2026-09-25 for *Who Gets to See the Light*.
